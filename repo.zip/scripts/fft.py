import numpy as np
import matplotlib.pyplot as plt

data = np.loadtxt("data.csv", delimiter=",")
vel = data[:, 0]   # raw_vel kanál (index 0)
Fs = 100.0         # 100 Hz výstup

freqs = np.fft.rfftfreq(len(vel), d=1/Fs)
mag = np.abs(np.fft.rfft(vel - np.mean(vel))) * 2 / len(vel)

plt.semilogy(freqs, mag)
plt.axvline(1.1, color='r', linestyle='--', label='cogging ~1.1 Hz')
plt.xlabel('Hz');  plt.ylabel('rad/s');  plt.xlim(0, 10)
plt.legend();  plt.show()